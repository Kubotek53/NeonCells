

## Goal
Make split player pieces merge back together smoothly (like agar.io) and add visible animations for active weapons.

## Changes to `src/components/AgarGame.tsx`

### 1. Piece re-merging (agar.io style)
- Keep the existing `PIECE_MERGE_TIME` (12s) cooldown — pieces become merge-eligible after that.
- Replace the current "separation only" logic between same-owner pieces with two behaviors based on cooldown:
  - **Before cooldown ends**: keep soft separation so they don't overlap.
  - **After cooldown ends**: apply gentle attraction pulling pieces toward each other. When two same-owner pieces overlap by ~60% of the smaller radius, fuse them into one piece — combine mass (`r = sqrt(r1² + r2²)`), average position weighted by mass, average velocity weighted by mass, and remove the smaller piece.
- After any fuse, recompute camera centroid/zoom from the reduced piece array.
- Apply the same merge rule to bots that have split (future-proof, currently bots don't split).

### 2. Weapon activation animations
Add a render pass for active weapon effects on the player pieces:

- **Drain (⚡ cyan)** while active:
  - Pulsing cyan ring around each player piece (radius oscillates with `sin(time)`), opacity fades with remaining time.
  - Particle stream: small cyan dots spawned each frame at nearby enemies, animated traveling toward the nearest player piece (lifetime ~400ms, fading + shrinking). Visualizes mass siphoning.
  - Soft cyan glow (canvas `shadowBlur`) on the player pieces.

- **Bomb (💣 red)** while armed:
  - Expanding/contracting red danger ring around each player piece.
  - Crackling red sparks orbiting the piece.
  - On detonation (first enemy hit): trigger a one-shot shockwave — expanding red ring (radius 0 → 200px over 500ms, fading out) plus radial debris particles. Stored in a new `effects` array and rendered/updated each frame.

- **HUD**: the existing weapon countdown badge gets a subtle pulse animation (CSS scale) while active.

### 3. Particle/effect system (lightweight)
Introduce a simple `effects: Effect[]` array in the game state:
```
type Effect = {
  kind: "drain-particle" | "spark" | "shockwave";
  x, y, vx, vy: number;
  life: number;        // remaining ms
  maxLife: number;
  color: string;
  size: number;
};
```
Update positions + life each frame, drop when `life <= 0`, render after entities so effects appear on top. Cap at ~200 active effects for performance.

### 4. Tuning constants (added near other constants)
```
PIECE_MERGE_ATTRACTION = 0.04   // pull strength once cooldown done
PIECE_FUSE_OVERLAP = 0.6        // overlap ratio to trigger fuse
DRAIN_PARTICLE_RATE = 3         // particles per frame per piece while draining
SHOCKWAVE_DURATION = 500        // ms
```

## Out of scope
- No changes to splitting input (double-tap / Space / dblclick stay).
- No changes to bot AI, food, or weapon spawn logic.
- No new files — all changes localized to `AgarGame.tsx`.

