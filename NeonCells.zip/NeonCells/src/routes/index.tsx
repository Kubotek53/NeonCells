import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { AgarGame } from "@/components/AgarGame";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Neon Cells — Agar.io Style Game" },
      { name: "description", content: "Eat, grow, dominate. A neon-drenched agar.io style multiplayer-feel game with smart bots." },
    ],
  }),
});

function Index() {
  const [phase, setPhase] = useState<"menu" | "play" | "over">("menu");
  const [name, setName] = useState("");
  const [photo, setPhoto] = useState<string | null>(null);
  const [finalScore, setFinalScore] = useState(0);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const onPickPhoto = (file: File | undefined) => {
    if (!file) return;
    // Downscale to ~256px square for perf
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const size = 256;
      const c = document.createElement("canvas");
      c.width = size; c.height = size;
      const ctx = c.getContext("2d")!;
      const s = Math.min(img.width, img.height);
      const sx = (img.width - s) / 2;
      const sy = (img.height - s) / 2;
      ctx.drawImage(img, sx, sy, s, s, 0, 0, size, size);
      setPhoto(c.toDataURL("image/jpeg", 0.85));
      URL.revokeObjectURL(url);
    };
    img.src = url;
  };

  if (phase === "play") {
    return (
      <AgarGame
        playerName={name || "You"}
        playerPhoto={photo}
        onGameOver={(s) => {
          setFinalScore(s);
          setPhase("over");
        }}
      />
    );
  }

  return (
    <main
      className="relative flex min-h-screen items-center justify-center overflow-hidden px-4"
      style={{ background: "radial-gradient(ellipse at top, oklch(0.22 0.08 280) 0%, oklch(0.1 0.04 270) 70%)" }}
    >
      {/* glow blobs */}
      <div className="pointer-events-none absolute -left-32 top-20 h-96 w-96 rounded-full opacity-40 blur-3xl" style={{ background: "#34d399" }} />
      <div className="pointer-events-none absolute -right-24 bottom-10 h-96 w-96 rounded-full opacity-40 blur-3xl" style={{ background: "#a78bfa" }} />
      <div className="pointer-events-none absolute right-1/3 top-1/2 h-72 w-72 rounded-full opacity-30 blur-3xl" style={{ background: "#22d3ee" }} />

      <div className="relative z-10 w-full max-w-md rounded-3xl border border-white/10 bg-black/40 p-8 backdrop-blur-xl">
        <h1
          className="text-center text-5xl font-black tracking-tight text-white"
          style={{ textShadow: "0 0 30px rgba(52,211,153,0.6)" }}
        >
          NEON <span style={{ color: "#34d399" }}>CELLS</span>
        </h1>
        <p className="mt-3 text-center text-sm text-white/60">
          Move with your mouse. Eat smaller cells. Avoid the bigger ones.
        </p>

        {phase === "over" && (
          <div className="mt-6 rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-4 text-center">
            <div className="text-xs uppercase tracking-widest text-emerald-300/80">Final mass</div>
            <div className="text-3xl font-bold text-white">{finalScore}</div>
          </div>
        )}

        <div className="mt-6 space-y-3">
          {/* Photo picker */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="group relative h-16 w-16 shrink-0 overflow-hidden rounded-full border-2 border-dashed border-white/20 bg-white/5 transition hover:border-emerald-400/60"
              aria-label="Upload photo"
            >
              {photo ? (
                <img src={photo} alt="Your avatar" className="h-full w-full object-cover" />
              ) : (
                <span className="flex h-full w-full items-center justify-center text-2xl text-white/40">＋</span>
              )}
            </button>
            <div className="flex-1">
              <div className="text-sm font-medium text-white">
                {photo ? "Looking good!" : "Add your photo"}
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="text-xs text-emerald-300 hover:text-emerald-200"
                >
                  {photo ? "Change" : "Upload"}
                </button>
                {photo && (
                  <button
                    type="button"
                    onClick={() => setPhoto(null)}
                    className="text-xs text-white/40 hover:text-white/70"
                  >
                    Remove
                  </button>
                )}
              </div>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => onPickPhoto(e.target.files?.[0])}
            />
          </div>

          <input
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 14))}
            placeholder="Enter your name"
            className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-white placeholder:text-white/40 outline-none transition focus:border-emerald-400/60 focus:bg-white/10"
          />
          <button
            onClick={() => setPhase("play")}
            className="w-full rounded-xl px-4 py-3 text-base font-bold text-black transition hover:scale-[1.02] active:scale-[0.98]"
            style={{
              background: "linear-gradient(135deg, #34d399, #22d3ee)",
              boxShadow: "0 10px 40px rgba(52,211,153,0.4)",
            }}
          >
            {phase === "over" ? "Play again" : "Start game"}
          </button>
        </div>

        <div className="mt-6 grid grid-cols-3 gap-2 text-center text-xs text-white/50">
          <div><div className="text-base text-white">🖱️</div>Mouse to move</div>
          <div><div className="text-base text-white">🟢</div>Eat food</div>
          <div><div className="text-base text-white">⚠️</div>Avoid bigger</div>
        </div>
      </div>
    </main>
  );
}
