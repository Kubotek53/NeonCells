import { useEffect, useRef, useState, useCallback } from "react";

type WeaponKind = "drain" | "bomb" | "shield" | "slime" | "teleport";

type Entity = {
  id: number;
  x: number;
  y: number;
  r: number;
  color: string;
  name?: string;
  vx?: number;
  vy?: number;
  isPlayer?: boolean;
  isBot?: boolean;
  targetX?: number;
  targetY?: number;
  ownerId?: number; // groups player pieces together
  mergeAt?: number; // performance.now()/1000 after which pieces can merge
  splitVx?: number;
  splitVy?: number;
  weapon?: WeaponKind | null;
  weaponUntil?: number; // weapon expiry time (seconds)
  shieldUntil?: number; // invincibility expiry time (seconds)
  // bot AI smoothing
  retargetAt?: number; // seconds; only re-pick a target after this time
  swerveSign?: number; // stable +1/-1 swerve direction while fleeing
};

type Weapon = {
  id: number;
  x: number;
  y: number;
  kind: WeaponKind;
};

type Effect = {
  kind: "drain-particle" | "spark" | "shockwave" | "teleport-flash";
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size: number;
  // for drain-particle: pull toward target piece
  targetId?: number;
  // for shockwave: expanding radius
  radius?: number;
  maxRadius?: number;
};

type SlimeTrap = {
  id: number;
  x: number;
  y: number;
  r: number;
  ownerId?: number;
  expiresAt: number; // seconds
};

const WORLD = 4000;
const FOOD_COUNT = 600;
const BOT_COUNT = 30;
const WEAPON_COUNT = 18;
const PIECE_MERGE_TIME = 12; // s before split pieces can merge
const MIN_SPLIT_R = 32;
const WEAPON_DURATION = 12; // s a weapon is active after pickup
const PIECE_MERGE_ATTRACTION = 0.04;
const PIECE_FUSE_OVERLAP = 0.6;
const DRAIN_PARTICLE_RATE = 3; // particles per drain-piece per frame
const SHOCKWAVE_DURATION = 500; // ms
const MAX_EFFECTS = 200;
const SHIELD_DURATION = 10; // s of invincibility
const SLIME_DURATION = 8; // s a slime trap lives on the ground
const SLIME_RADIUS = 70;
const SLIME_SLOW = 0.25; // movement multiplier while stuck
const TELEPORT_RANGE = 600; // px world distance the teleport can blink
const COLORS = [
  "#34d399", "#22d3ee", "#f472b6", "#fbbf24",
  "#a78bfa", "#f87171", "#60a5fa", "#fb923c",
];
const BOT_NAMES = [
  "Blob", "Snack", "Vortex", "Nimbus", "Pixel", "Quasar",
  "Echo", "Drift", "Lumen", "Cipher", "Nova", "Zephyr",
  "Orbit", "Glow",
];

let idCounter = 1;
const nid = () => idCounter++;

const rand = (min: number, max: number) => Math.random() * (max - min) + min;
const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];

function makeFood(): Entity {
  return {
    id: nid(),
    x: rand(0, WORLD),
    y: rand(0, WORLD),
    r: 6,
    color: pick(COLORS),
  };
}

function makeBot(): Entity {
  return {
    id: nid(),
    x: rand(100, WORLD - 100),
    y: rand(100, WORLD - 100),
    r: rand(18, 40),
    color: pick(COLORS),
    name: pick(BOT_NAMES),
    isBot: true,
    targetX: rand(0, WORLD),
    targetY: rand(0, WORLD),
  };
}

function makeWeapon(): Weapon {
  const r = Math.random();
  let kind: WeaponKind;
  if (r < 0.28) kind = "drain";
  else if (r < 0.5) kind = "bomb";
  else if (r < 0.7) kind = "shield";
  else if (r < 0.88) kind = "slime";
  else kind = "teleport";
  return {
    id: nid(),
    x: rand(50, WORLD - 50),
    y: rand(50, WORLD - 50),
    kind,
  };
}

const massFromR = (r: number) => Math.PI * r * r;
const rFromMass = (m: number) => Math.sqrt(m / Math.PI);
const speedFor = (r: number) => Math.max(1.2, 6 - Math.log2(r) * 0.7);

export function AgarGame({
  playerName,
  playerPhoto,
  onGameOver,
}: {
  playerName: string;
  playerPhoto?: string | null;
  onGameOver: (score: number) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const photoRef = useRef<HTMLImageElement | null>(null);
  const minimapRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!playerPhoto) {
      photoRef.current = null;
      return;
    }
    const img = new Image();
    img.onload = () => {
      photoRef.current = img;
    };
    img.src = playerPhoto;
  }, [playerPhoto]);

  const playerOwnerId = useRef(nid()).current;

  const stateRef = useRef({
    pieces: [
      {
        id: nid(),
        x: WORLD / 2,
        y: WORLD / 2,
        r: 22,
        color: "#34d399",
        name: playerName,
        isPlayer: true,
        ownerId: playerOwnerId,
        mergeAt: 0,
      } as Entity,
    ] as Entity[],
    food: [] as Entity[],
    bots: [] as Entity[],
    weapons: [] as Weapon[],
    effects: [] as Effect[],
    slimes: [] as SlimeTrap[],
    mouse: { x: 0, y: 0 },
    touch: { active: false, x: 0, y: 0 },
    cam: { x: WORLD / 2, y: WORLD / 2, zoom: 1 },
    alive: true,
    lastTap: 0,
  });
  const [score, setScore] = useState(0);
  const [leaderboard, setLeaderboard] = useState<{ name: string; score: number; isPlayer?: boolean }[]>([]);
  const [activeWeapon, setActiveWeapon] = useState<{ kind: WeaponKind; until: number } | null>(null);

  // init
  useEffect(() => {
    const s = stateRef.current;
    s.food = Array.from({ length: FOOD_COUNT }, makeFood);
    s.bots = Array.from({ length: BOT_COUNT }, makeBot);
    s.weapons = Array.from({ length: WEAPON_COUNT }, makeWeapon);
  }, []);

  const resize = useCallback(() => {
    const c = canvasRef.current;
    if (!c) return;
    c.width = window.innerWidth;
    c.height = window.innerHeight;
  }, []);

  useEffect(() => {
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, [resize]);

  // mouse
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      stateRef.current.mouse.x = e.clientX;
      stateRef.current.mouse.y = e.clientY;
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  // split logic — splits all eligible player pieces toward cursor/touch
  const trySplit = useCallback(() => {
    const s = stateRef.current;
    if (!s.alive) return;
    const c = canvasRef.current;
    if (!c) return;
    const cx = c.width / 2, cy = c.height / 2;
    const inputX = s.touch.active ? s.touch.x : s.mouse.x;
    const inputY = s.touch.active ? s.touch.y : s.mouse.y;
    const dx = inputX - cx, dy = inputY - cy;
    const dist = Math.hypot(dx, dy) || 1;
    const dirX = dx / dist, dirY = dy / dist;
    const now = performance.now() / 1000;
    const newPieces: Entity[] = [];
    for (const p of s.pieces) {
      if (!p.isPlayer) continue;
      if (p.r < MIN_SPLIT_R) continue;
      if (s.pieces.length + newPieces.length >= 8) break;
      const newR = rFromMass(massFromR(p.r) / 2);
      p.r = newR;
      p.mergeAt = now + PIECE_MERGE_TIME;
      const speed = 18 + p.r * 0.2;
      newPieces.push({
        id: nid(),
        x: p.x,
        y: p.y,
        r: newR,
        color: p.color,
        name: p.name,
        isPlayer: true,
        ownerId: p.ownerId,
        mergeAt: now + PIECE_MERGE_TIME,
        splitVx: dirX * speed,
        splitVy: dirY * speed,
        weapon: p.weapon,
        weaponUntil: p.weaponUntil,
      });
    }
    s.pieces.push(...newPieces);
  }, []);

  // touch — track double-tap to split
  useEffect(() => {
    const setTouch = (e: TouchEvent) => {
      if (e.touches.length === 0) return;
      const t = e.touches[0];
      const s = stateRef.current;
      s.touch.active = true;
      s.touch.x = t.clientX;
      s.touch.y = t.clientY;
      e.preventDefault();
    };
    const onTouchStart = (e: TouchEvent) => {
      setTouch(e);
      const now = performance.now();
      if (now - stateRef.current.lastTap < 300) {
        trySplit();
        stateRef.current.lastTap = 0;
      } else {
        stateRef.current.lastTap = now;
      }
    };
    const endTouch = (e: TouchEvent) => {
      if (e.touches.length === 0) stateRef.current.touch.active = false;
    };
    window.addEventListener("touchstart", onTouchStart, { passive: false });
    window.addEventListener("touchmove", setTouch, { passive: false });
    window.addEventListener("touchend", endTouch);
    window.addEventListener("touchcancel", endTouch);
    return () => {
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchmove", setTouch);
      window.removeEventListener("touchend", endTouch);
      window.removeEventListener("touchcancel", endTouch);
    };
  }, [trySplit]);

  // mouse double-click + space to split
  useEffect(() => {
    const onDbl = () => trySplit();
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        e.preventDefault();
        trySplit();
      }
    };
    window.addEventListener("dblclick", onDbl);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("dblclick", onDbl);
      window.removeEventListener("keydown", onKey);
    };
  }, [trySplit]);

  // click-to-activate weapons (slime trap drop, teleport blink, shield burst)
  const tryActivateWeapon = useCallback(() => {
    const s = stateRef.current;
    if (!s.alive) return;
    const c = canvasRef.current;
    if (!c) return;
    const tnow = performance.now() / 1000;
    // find a player piece carrying an activatable weapon
    const piece = s.pieces.find(
      (p) => p.isPlayer && (p.weapon === "slime" || p.weapon === "teleport" || p.weapon === "shield"),
    );
    if (!piece) return;
    // compute world target from cursor
    const inputX = s.touch.active ? s.touch.x : s.mouse.x;
    const inputY = s.touch.active ? s.touch.y : s.mouse.y;
    const wx = s.cam.x + (inputX - c.width / 2) / s.cam.zoom;
    const wy = s.cam.y + (inputY - c.height / 2) / s.cam.zoom;

    if (piece.weapon === "slime") {
      // drop slime trap at cursor location (clamped)
      const tx = Math.max(SLIME_RADIUS, Math.min(WORLD - SLIME_RADIUS, wx));
      const ty = Math.max(SLIME_RADIUS, Math.min(WORLD - SLIME_RADIUS, wy));
      s.slimes.push({
        id: nid(),
        x: tx,
        y: ty,
        r: SLIME_RADIUS,
        ownerId: piece.ownerId,
        expiresAt: tnow + SLIME_DURATION,
      });
      // consume
      for (const p of s.pieces) {
        if (p.isPlayer && p.weapon === "slime") {
          p.weapon = null;
          p.weaponUntil = 0;
        }
      }
    } else if (piece.weapon === "teleport") {
      // blink all player pieces toward cursor (clamped to TELEPORT_RANGE)
      for (const p of s.pieces.filter((pp) => pp.isPlayer)) {
        const dx = wx - p.x, dy = wy - p.y;
        const d = Math.hypot(dx, dy) || 1;
        const dist = Math.min(d, TELEPORT_RANGE);
        const fromX = p.x, fromY = p.y;
        p.x = Math.max(p.r, Math.min(WORLD - p.r, p.x + (dx / d) * dist));
        p.y = Math.max(p.r, Math.min(WORLD - p.r, p.y + (dy / d) * dist));
        p.splitVx = 0; p.splitVy = 0;
        // flash effects at both ends
        for (const [fx, fy] of [[fromX, fromY], [p.x, p.y]] as const) {
          if (s.effects.length >= MAX_EFFECTS) break;
          s.effects.push({
            kind: "teleport-flash",
            x: fx, y: fy, vx: 0, vy: 0,
            life: 450, maxLife: 450,
            color: "#a78bfa",
            size: p.r,
            radius: 0, maxRadius: p.r * 2.5,
          });
        }
        p.weapon = null;
        p.weaponUntil = 0;
      }
    } else if (piece.weapon === "shield") {
      // grant invincibility to ALL player pieces
      for (const p of s.pieces.filter((pp) => pp.isPlayer)) {
        p.shieldUntil = tnow + SHIELD_DURATION;
        p.weapon = null;
        p.weaponUntil = 0;
      }
    }
  }, []);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      // single left click only; ignore double-clicks (handled separately)
      if (e.detail > 1) return;
      tryActivateWeapon();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "KeyQ" || e.code === "KeyE") {
        e.preventDefault();
        tryActivateWeapon();
      }
    };
    window.addEventListener("click", onClick);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("click", onClick);
      window.removeEventListener("keydown", onKey);
    };
  }, [tryActivateWeapon]);

  // game loop
  useEffect(() => {
    let raf = 0;
    let last = performance.now();

    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const tnow = now / 1000;
      const s = stateRef.current;
      const c = canvasRef.current;
      if (!c) {
        raf = requestAnimationFrame(tick);
        return;
      }
      const ctx = c.getContext("2d")!;
      const W = c.width, H = c.height;

      // expire slime traps
      for (let i = s.slimes.length - 1; i >= 0; i--) {
        if (s.slimes[i].expiresAt <= tnow) s.slimes.splice(i, 1);
      }

      // returns slowdown multiplier (1 = normal) if entity is inside a hostile slime
      const slimeFactor = (e: Entity) => {
        for (const sl of s.slimes) {
          if (sl.ownerId && sl.ownerId === e.ownerId) continue;
          if (Math.hypot(sl.x - e.x, sl.y - e.y) < sl.r) return SLIME_SLOW;
        }
        return 1;
      };

      // compute player centroid for camera + input
      const playerPieces = s.pieces.filter((p) => p.isPlayer);
      const totalMass = playerPieces.reduce((m, p) => m + massFromR(p.r), 0);
      let pcx = WORLD / 2, pcy = WORLD / 2;
      if (playerPieces.length > 0 && totalMass > 0) {
        let sx = 0, sy = 0;
        for (const p of playerPieces) {
          const m = massFromR(p.r);
          sx += p.x * m; sy += p.y * m;
        }
        pcx = sx / totalMass; pcy = sy / totalMass;
      }

      if (s.alive && playerPieces.length > 0) {
        const cx = W / 2, cy = H / 2;
        const inputX = s.touch.active ? s.touch.x : s.mouse.x;
        const inputY = s.touch.active ? s.touch.y : s.mouse.y;
        const dx = inputX - cx;
        const dy = inputY - cy;
        const dist = Math.hypot(dx, dy);

        for (const p of playerPieces) {
          // apply split impulse
          if (p.splitVx || p.splitVy) {
            p.x += (p.splitVx || 0);
            p.y += (p.splitVy || 0);
            p.splitVx = (p.splitVx || 0) * 0.85;
            p.splitVy = (p.splitVy || 0) * 0.85;
            if (Math.abs(p.splitVx) < 0.2) p.splitVx = 0;
            if (Math.abs(p.splitVy) < 0.2) p.splitVy = 0;
          }
          if (dist > 4) {
            const sp = speedFor(p.r);
            const f = s.touch.active ? 1 : Math.min(1, dist / 200);
            const sf = slimeFactor(p);
            p.x += (dx / dist) * sp * f * sf * 60 * dt;
            p.y += (dy / dist) * sp * f * sf * 60 * dt;
          }
          p.x = Math.max(p.r, Math.min(WORLD - p.r, p.x));
          p.y = Math.max(p.r, Math.min(WORLD - p.r, p.y));
        }

        // same-owner piece interactions: attract + fuse after cooldown, separate before
        const groups = new Map<number, Entity[]>();
        for (const p of s.pieces) {
          if (!p.ownerId) continue;
          const g = groups.get(p.ownerId);
          if (g) g.push(p);
          else groups.set(p.ownerId, [p]);
        }
        for (const g of groups.values()) {
          if (g.length < 2) continue;
          for (let i = 0; i < g.length; i++) {
            for (let j = i + 1; j < g.length; j++) {
              const a = g[i], b = g[j];
              if (!s.pieces.includes(a) || !s.pieces.includes(b)) continue;
              const ddx = b.x - a.x, ddy = b.y - a.y;
              const d = Math.hypot(ddx, ddy) || 0.01;
              const canMerge = (a.mergeAt || 0) <= tnow && (b.mergeAt || 0) <= tnow;
              const minD = a.r + b.r;
              if (canMerge) {
                const small = a.r < b.r ? a : b;
                const big = a.r < b.r ? b : a;
                const overlap = (minD - d) / Math.max(small.r * 2, 1);
                if (d < minD * (1 - PIECE_FUSE_OVERLAP) || overlap > PIECE_FUSE_OVERLAP) {
                  // fuse — combine mass into big, weighted average pos/vel
                  const mA = massFromR(big.r), mB = massFromR(small.r);
                  const mTot = mA + mB;
                  big.x = (big.x * mA + small.x * mB) / mTot;
                  big.y = (big.y * mA + small.y * mB) / mTot;
                  big.splitVx = ((big.splitVx || 0) * mA + (small.splitVx || 0) * mB) / mTot;
                  big.splitVy = ((big.splitVy || 0) * mA + (small.splitVy || 0) * mB) / mTot;
                  big.r = rFromMass(mTot);
                  if (small.weapon && (!big.weapon || (small.weaponUntil || 0) > (big.weaponUntil || 0))) {
                    big.weapon = small.weapon;
                    big.weaponUntil = small.weaponUntil;
                  }
                  const idx = s.pieces.indexOf(small);
                  if (idx >= 0) s.pieces.splice(idx, 1);
                } else {
                  // gentle attraction
                  const pull = PIECE_MERGE_ATTRACTION * 60 * dt;
                  a.x += (ddx / d) * pull * a.r;
                  a.y += (ddy / d) * pull * a.r;
                  b.x -= (ddx / d) * pull * b.r;
                  b.y -= (ddy / d) * pull * b.r;
                }
              } else {
                // cooldown active: gently drift together when apart, rest when touching
                // deadband prevents bouncing between attract & separate
                if (d > minD * 1.05) {
                  const pull = PIECE_MERGE_ATTRACTION * 0.4 * 60 * dt;
                  a.x += (ddx / d) * pull * a.r;
                  a.y += (ddy / d) * pull * a.r;
                  b.x -= (ddx / d) * pull * b.r;
                  b.y -= (ddy / d) * pull * b.r;
                } else if (d < minD * 0.98) {
                  // gentle, damped separation only when actually overlapping
                  const overlap = (minD - d) * 0.25;
                  a.x -= (ddx / d) * overlap;
                  a.y -= (ddy / d) * overlap;
                  b.x += (ddx / d) * overlap;
                  b.y += (ddy / d) * overlap;
                }
                // dead zone (0.98–1.05 * minD): no force, pieces rest against each other
              }
            }
          }
        }
      }

      // bot AI — smarter: scored threat/prey/food/weapon decisions
      const allLiving: Entity[] = [...s.pieces, ...s.bots];
      const tNowSec = performance.now() / 1000;
      for (const b of s.bots) {
        let tx = b.targetX!, ty = b.targetY!;
        let urgency = 1; // speed multiplier (used when fleeing)

        // Only re-evaluate targets a few times per second to prevent jitter.
        // Always re-check threats (safety), but reuse prey/food/weapon target.
        const canRetarget = !b.retargetAt || tNowSec >= b.retargetAt;

        // 1. Find biggest threat (weighted by closeness + size) — every frame
        let threat: Entity | null = null;
        let threatScore = 0;
        const dangerRange = 320 + b.r * 2;
        for (const o of allLiving) {
          if (o.id === b.id) continue;
          if (o.r <= b.r * 1.15) continue;
          const d = Math.hypot(o.x - b.x, o.y - b.y);
          if (d > dangerRange) continue;
          // closer & bigger = scarier; weapon-holders are extra scary
          const score = (o.r / b.r) * (1 - d / dangerRange) * (o.weapon ? 1.6 : 1);
          if (score > threatScore) { threatScore = score; threat = o; }
        }

        // Decision priority: flee > hunt prey > grab weapon > eat food > wander
        if (threat) {
          // stable swerve sign so flee direction doesn't flip every frame
          if (b.swerveSign === undefined) b.swerveSign = b.id % 2 === 0 ? 1 : -1;
          const ax = b.x - threat.x, ay = b.y - threat.y;
          const ad = Math.hypot(ax, ay) || 1;
          const px = -ay / ad, py = ax / ad;
          const swerve = b.swerveSign * 0.5;
          // project a far-away flee point so the absolute target stays stable
          // as the bot moves (was: relative to b.x/b.y → jittered every frame)
          tx = threat.x + (ax / ad + px * swerve) * 1200;
          ty = threat.y + (ay / ad + py * swerve) * 1200;
          urgency = 1.2;
          b.retargetAt = tNowSec + 0.15; // refresh flee target often
        } else if (canRetarget) {
          // recompute prey/weapon/food only on retarget tick (prevents shaking)
          // 2. Find best prey
          let prey: Entity | null = null;
          let preyScore = 0;
          for (const o of allLiving) {
            if (o.id === b.id) continue;
            if (b.r <= o.r * 1.15) continue;
            const d = Math.hypot(o.x - b.x, o.y - b.y);
            if (d > 500) continue;
            const score = (b.r / Math.max(o.r, 1)) * (1 - d / 500);
            if (score > preyScore) { preyScore = score; prey = o; }
          }
          // 3. Nearest food
          let bestFood: Entity | null = null;
          let bestFoodD = 400 * 400;
          for (const f of s.food) {
            const d = (f.x - b.x) ** 2 + (f.y - b.y) ** 2;
            if (d < bestFoodD) { bestFoodD = d; bestFood = f; }
          }
          // 4. Nearby weapon
          let bestWeapon: Weapon | null = null;
          let bestWeaponD = 350 * 350;
          for (const w of s.weapons) {
            const d = (w.x - b.x) ** 2 + (w.y - b.y) ** 2;
            if (d < bestWeaponD) { bestWeaponD = d; bestWeapon = w; }
          }
          if (prey && preyScore > 0.3) {
            tx = prey.x; ty = prey.y;
          } else if (bestWeapon && !b.weapon) {
            tx = bestWeapon.x; ty = bestWeapon.y;
          } else if (bestFood) {
            tx = bestFood.x; ty = bestFood.y;
          } else {
            // no prey/food/weapon nearby OR we're already at our target —
            // pick a fresh wander point so bots never stand idle
            const reached = Math.hypot((b.targetX ?? b.x) - b.x, (b.targetY ?? b.y) - b.y) < b.r * 1.5;
            if (reached || Math.random() < 0.5) {
              const ang = Math.random() * Math.PI * 2;
              const dist = 400 + Math.random() * 600;
              tx = Math.max(80, Math.min(WORLD - 80, b.x + Math.cos(ang) * dist));
              ty = Math.max(80, Math.min(WORLD - 80, b.y + Math.sin(ang) * dist));
            }
          }
          // hold this target for 200–350ms — kills per-frame jitter
          b.retargetAt = tNowSec + 0.25 + Math.random() * 0.2;
          // reset swerve sign so next flee picks fresh
          b.swerveSign = undefined;
        }

        // avoid edges — nudge target inward if hugging wall
        const edgePad = 120;
        if (b.x < edgePad) tx = Math.max(tx, edgePad);
        if (b.x > WORLD - edgePad) tx = Math.min(tx, WORLD - edgePad);
        if (b.y < edgePad) ty = Math.max(ty, edgePad);
        if (b.y > WORLD - edgePad) ty = Math.min(ty, WORLD - edgePad);

        b.targetX = tx; b.targetY = ty;
        const bdx = tx - b.x, bdy = ty - b.y, bd = Math.hypot(bdx, bdy);
        // deadzone prevents jitter when target is inside/near the bot's radius
        const deadzone = Math.max(6, b.r * 0.4);
        if (bd > deadzone) {
          const sp = speedFor(b.r) * urgency;
          // ease speed when close so we don't overshoot and oscillate
          const ease = Math.min(1, (bd - deadzone) / 40);
          const sf = slimeFactor(b);
          b.x += (bdx / bd) * sp * ease * sf * 60 * dt;
          b.y += (bdy / bd) * sp * ease * sf * 60 * dt;
        }
        b.x = Math.max(b.r, Math.min(WORLD - b.r, b.x));
        b.y = Math.max(b.r, Math.min(WORLD - b.r, b.y));
      }

      // bot auto-trigger of activatable weapons
      for (const b of s.bots) {
        if (!b.weapon) continue;
        if (b.weapon === "slime") {
          // drop a slime if a chasing threat is close behind us
          for (const o of allLiving) {
            if (o.id === b.id) continue;
            if (o.r <= b.r * 1.1) continue;
            const d = Math.hypot(o.x - b.x, o.y - b.y);
            if (d < b.r + 220) {
              s.slimes.push({
                id: nid(),
                x: b.x,
                y: b.y,
                r: SLIME_RADIUS,
                ownerId: b.id, // bots use their own id as owner (no group)
                expiresAt: tnow + SLIME_DURATION,
              });
              b.weapon = null; b.weaponUntil = 0;
              break;
            }
          }
        } else if (b.weapon === "teleport") {
          // blink away from a chasing threat (or toward prey if safe)
          let danger: Entity | null = null;
          let dangerD = Infinity;
          for (const o of allLiving) {
            if (o.id === b.id) continue;
            if (o.r <= b.r * 1.1) continue;
            const d = Math.hypot(o.x - b.x, o.y - b.y);
            if (d < b.r + 240 && d < dangerD) { dangerD = d; danger = o; }
          }
          if (danger) {
            const dx = b.x - danger.x, dy = b.y - danger.y;
            const d = Math.hypot(dx, dy) || 1;
            const fromX = b.x, fromY = b.y;
            b.x = Math.max(b.r, Math.min(WORLD - b.r, b.x + (dx / d) * TELEPORT_RANGE));
            b.y = Math.max(b.r, Math.min(WORLD - b.r, b.y + (dy / d) * TELEPORT_RANGE));
            for (const [fx, fy] of [[fromX, fromY], [b.x, b.y]] as const) {
              if (s.effects.length >= MAX_EFFECTS) break;
              s.effects.push({
                kind: "teleport-flash",
                x: fx, y: fy, vx: 0, vy: 0,
                life: 450, maxLife: 450,
                color: "#a78bfa",
                size: b.r,
                radius: 0, maxRadius: b.r * 2.5,
              });
            }
            b.weapon = null; b.weaponUntil = 0;
          }
        }
      }

      // eat food
      const eatFood = (e: Entity) => {
        for (let i = s.food.length - 1; i >= 0; i--) {
          const f = s.food[i];
          const d = Math.hypot(f.x - e.x, f.y - e.y);
          if (d < e.r) {
            e.r = rFromMass(massFromR(e.r) + massFromR(f.r));
            s.food.splice(i, 1);
            s.food.push(makeFood());
          }
        }
      };
      for (const p of s.pieces) eatFood(p);
      for (const b of s.bots) eatFood(b);

      // pick up weapons
      for (let i = s.weapons.length - 1; i >= 0; i--) {
        const w = s.weapons[i];
        for (const e of [...s.pieces, ...s.bots]) {
          const d = Math.hypot(w.x - e.x, w.y - e.y);
          if (d < e.r) {
            if (w.kind === "shield") {
              // auto-activate: grant invincibility immediately
              const owner = e.ownerId;
              if (e.isPlayer && owner) {
                for (const p of s.pieces) if (p.ownerId === owner) p.shieldUntil = tnow + SHIELD_DURATION;
              } else {
                e.shieldUntil = tnow + SHIELD_DURATION;
              }
            } else if (w.kind === "slime" || w.kind === "teleport") {
              // carryable; bots trigger automatically below; player triggers via click
              e.weapon = w.kind;
              e.weaponUntil = tnow + WEAPON_DURATION;
            } else {
              e.weapon = w.kind;
              e.weaponUntil = tnow + WEAPON_DURATION;
            }
            s.weapons.splice(i, 1);
            // respawn after a short delay
            setTimeout(() => stateRef.current.weapons.push(makeWeapon()), 1500);
            break;
          }
        }
      }

      // expire weapons
      for (const e of [...s.pieces, ...s.bots]) {
        if (e.weapon && (e.weaponUntil || 0) < tnow) {
          e.weapon = null;
          e.weaponUntil = 0;
        }
      }

      // weapon effects: drain steals mass from nearby targets, bomb explodes near target
      const allEntities: Entity[] = [...s.pieces, ...s.bots];
      for (const e of allEntities) {
        if (!e.weapon) continue;
        if (e.weapon === "drain") {
          for (const t of allEntities) {
            if (t === e) continue;
            if (t.ownerId && t.ownerId === e.ownerId) continue;
            if ((t.shieldUntil || 0) > tnow) continue;
            const d = Math.hypot(t.x - e.x, t.y - e.y);
            const range = e.r + 90;
            if (d < range && t.r > 12) {
              const steal = Math.min(massFromR(t.r) * 0.02 * dt * 5, massFromR(t.r) - massFromR(10));
              if (steal > 0) {
                t.r = rFromMass(Math.max(massFromR(10), massFromR(t.r) - steal));
                e.r = rFromMass(massFromR(e.r) + steal * 0.7);
                // spawn drain particles flowing from target toward e
                if (s.effects.length < MAX_EFFECTS) {
                  for (let k = 0; k < DRAIN_PARTICLE_RATE; k++) {
                    const ang = Math.random() * Math.PI * 2;
                    s.effects.push({
                      kind: "drain-particle",
                      x: t.x + Math.cos(ang) * t.r * 0.7,
                      y: t.y + Math.sin(ang) * t.r * 0.7,
                      vx: 0, vy: 0,
                      life: 400, maxLife: 400,
                      color: "#22d3ee",
                      size: 3 + Math.random() * 2,
                      targetId: e.id,
                    });
                  }
                }
              }
            }
          }
          // pulsing orbiting sparks around e (subtle)
          if (s.effects.length < MAX_EFFECTS && Math.random() < 0.3) {
            const ang = Math.random() * Math.PI * 2;
            s.effects.push({
              kind: "spark",
              x: e.x + Math.cos(ang) * (e.r + 10),
              y: e.y + Math.sin(ang) * (e.r + 10),
              vx: Math.cos(ang) * 0.5,
              vy: Math.sin(ang) * 0.5,
              life: 350, maxLife: 350,
              color: "#22d3ee",
              size: 2,
            });
          }
        } else if (e.weapon === "bomb") {
          // crackling red sparks orbiting
          if (s.effects.length < MAX_EFFECTS && Math.random() < 0.6) {
            const ang = Math.random() * Math.PI * 2;
            const orbitR = e.r + 8 + Math.random() * 8;
            s.effects.push({
              kind: "spark",
              x: e.x + Math.cos(ang) * orbitR,
              y: e.y + Math.sin(ang) * orbitR,
              vx: -Math.sin(ang) * 1.5,
              vy: Math.cos(ang) * 1.5,
              life: 400, maxLife: 400,
              color: "#f87171",
              size: 2 + Math.random() * 2,
            });
          }
          // bomb fires once when an enemy enters range, then expires
          let fired = false;
          for (const t of allEntities) {
            if (fired) break;
            if (t === e) continue;
            if (t.ownerId && t.ownerId === e.ownerId) continue;
            if ((t.shieldUntil || 0) > tnow) continue;
            const d = Math.hypot(t.x - e.x, t.y - e.y);
            if (d < e.r + 70) {
              const stolen = massFromR(t.r) * 0.18;
              t.r = rFromMass(Math.max(massFromR(10), massFromR(t.r) - stolen));
              e.r = rFromMass(massFromR(e.r) + stolen * 0.6);
              e.weapon = null;
              e.weaponUntil = 0;
              fired = true;
              // shockwave + debris
              s.effects.push({
                kind: "shockwave",
                x: t.x, y: t.y,
                vx: 0, vy: 0,
                life: SHOCKWAVE_DURATION, maxLife: SHOCKWAVE_DURATION,
                color: "#f87171",
                size: 0,
                radius: 0, maxRadius: 200,
              });
              for (let k = 0; k < 24; k++) {
                const ang = (k / 24) * Math.PI * 2;
                const sp = 4 + Math.random() * 3;
                if (s.effects.length >= MAX_EFFECTS) break;
                s.effects.push({
                  kind: "spark",
                  x: t.x, y: t.y,
                  vx: Math.cos(ang) * sp,
                  vy: Math.sin(ang) * sp,
                  life: 600, maxLife: 600,
                  color: "#f87171",
                  size: 3 + Math.random() * 2,
                });
              }
            }
          }
        }
      }

      // entity collisions (eating)
      const all: Entity[] = [...s.pieces, ...s.bots];
      for (let i = 0; i < all.length; i++) {
        for (let j = i + 1; j < all.length; j++) {
          const a = all[i], b = all[j];
          // skip same-owner player pieces (handled by merge logic)
          if (a.ownerId && a.ownerId === b.ownerId) continue;
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          const big = a.r > b.r ? a : b;
          const small = a.r > b.r ? b : a;
          if (big.r > small.r * 1.1 && d < big.r - small.r * 0.4) {
            // shield protects the smaller from being eaten
            if ((small.shieldUntil || 0) > tnow) continue;
            big.r = rFromMass(massFromR(big.r) + massFromR(small.r));
            if (small.isPlayer) {
              const idx = s.pieces.indexOf(small);
              if (idx >= 0) s.pieces.splice(idx, 1);
              if (s.pieces.filter((p) => p.isPlayer).length === 0) {
                s.alive = false;
                const finalMass = Math.floor(massFromR(small.r));
                setTimeout(() => onGameOver(finalMass), 50);
              }
            } else if (small.isBot) {
              const idx = s.bots.indexOf(small);
              if (idx >= 0) s.bots.splice(idx, 1);
              s.bots.push(makeBot());
            }
          }
        }
      }

      // camera — follow player centroid, zoom by total mass
      const totalR = rFromMass(totalMass || massFromR(22));
      const targetZoom = Math.max(0.35, Math.min(1.2, 60 / totalR));
      s.cam.zoom += (targetZoom - s.cam.zoom) * 0.05;
      s.cam.x += (pcx - s.cam.x) * 0.12;
      s.cam.y += (pcy - s.cam.y) * 0.12;

      // ---- render ----
      ctx.fillStyle = "#0a0a18";
      ctx.fillRect(0, 0, W, H);

      ctx.save();
      ctx.translate(W / 2, H / 2);
      ctx.scale(s.cam.zoom, s.cam.zoom);
      ctx.translate(-s.cam.x, -s.cam.y);

      // grid
      const gridSize = 50;
      const minX = s.cam.x - W / 2 / s.cam.zoom;
      const maxX = s.cam.x + W / 2 / s.cam.zoom;
      const minY = s.cam.y - H / 2 / s.cam.zoom;
      const maxY = s.cam.y + H / 2 / s.cam.zoom;
      ctx.strokeStyle = "rgba(120, 140, 220, 0.08)";
      ctx.lineWidth = 1 / s.cam.zoom;
      const sx = Math.floor(minX / gridSize) * gridSize;
      const sy = Math.floor(minY / gridSize) * gridSize;
      ctx.beginPath();
      for (let x = sx; x < maxX; x += gridSize) {
        ctx.moveTo(x, minY); ctx.lineTo(x, maxY);
      }
      for (let y = sy; y < maxY; y += gridSize) {
        ctx.moveTo(minX, y); ctx.lineTo(maxX, y);
      }
      ctx.stroke();

      // world bounds
      ctx.strokeStyle = "rgba(167, 139, 250, 0.4)";
      ctx.lineWidth = 4 / s.cam.zoom;
      ctx.strokeRect(0, 0, WORLD, WORLD);

      // food
      for (const f of s.food) {
        if (f.x < minX - 20 || f.x > maxX + 20 || f.y < minY - 20 || f.y > maxY + 20) continue;
        ctx.fillStyle = f.color;
        ctx.shadowColor = f.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.shadowBlur = 0;

      // slime traps (rendered under entities)
      for (const sl of s.slimes) {
        if (sl.x < minX - sl.r || sl.x > maxX + sl.r || sl.y < minY - sl.r || sl.y > maxY + sl.r) continue;
        const remain = Math.max(0, sl.expiresAt - tnow);
        const fade = Math.min(1, remain / 2);
        ctx.save();
        ctx.globalAlpha = 0.35 * fade + 0.25;
        const grad = ctx.createRadialGradient(sl.x, sl.y, sl.r * 0.2, sl.x, sl.y, sl.r);
        grad.addColorStop(0, "rgba(132, 204, 22, 0.9)");
        grad.addColorStop(1, "rgba(132, 204, 22, 0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(sl.x, sl.y, sl.r, 0, Math.PI * 2);
        ctx.fill();
        // wobbling ring
        ctx.globalAlpha = 0.7 * fade;
        ctx.strokeStyle = "#84cc16";
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 4]);
        ctx.lineDashOffset = -tnow * 20;
        ctx.beginPath();
        ctx.arc(sl.x, sl.y, sl.r * (0.95 + Math.sin(tnow * 4) * 0.04), 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      }

      // weapons (pickups)
      for (const w of s.weapons) {
        if (w.x < minX - 30 || w.x > maxX + 30 || w.y < minY - 30 || w.y > maxY + 30) continue;
        const color =
          w.kind === "drain" ? "#22d3ee" :
          w.kind === "bomb" ? "#f87171" :
          w.kind === "shield" ? "#60a5fa" :
          w.kind === "slime" ? "#84cc16" :
          "#a78bfa"; // teleport
        const icon =
          w.kind === "drain" ? "⚡" :
          w.kind === "bomb" ? "💣" :
          w.kind === "shield" ? "🛡️" :
          w.kind === "slime" ? "🟢" :
          "✨";
        ctx.save();
        ctx.translate(w.x, w.y);
        ctx.rotate((now / 600) % (Math.PI * 2));
        ctx.shadowColor = color;
        ctx.shadowBlur = 18;
        ctx.fillStyle = color;
        ctx.beginPath();
        // star-ish diamond
        const R = 14;
        ctx.moveTo(0, -R);
        ctx.lineTo(R * 0.5, 0);
        ctx.lineTo(0, R);
        ctx.lineTo(-R * 0.5, 0);
        ctx.closePath();
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "white";
        ctx.font = "bold 14px ui-sans-serif, system-ui";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(icon, 0, 1);
        ctx.restore();
      }

      // entities (sorted by size so big render on top)
      const drawList = [...s.pieces, ...s.bots].slice().sort((a, b) => a.r - b.r);
      for (const e of drawList) {
        ctx.save();
        ctx.shadowColor = e.weapon === "drain" ? "#22d3ee" : e.weapon === "bomb" ? "#f87171" : e.color;
        ctx.shadowBlur = e.weapon ? 32 + Math.sin(tnow * 6) * 10 : 20;
        ctx.fillStyle = e.color;
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        // shield bubble (rendered behind details)
        if ((e.shieldUntil || 0) > tnow) {
          const remain = (e.shieldUntil || 0) - tnow;
          const fade = Math.min(1, remain / 2);
          const wobble = 4 + Math.sin(tnow * 5) * 3;
          ctx.save();
          ctx.globalAlpha = 0.18 + 0.12 * fade;
          ctx.fillStyle = "#60a5fa";
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r + wobble + 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 0.9 * fade;
          ctx.strokeStyle = "#bfdbfe";
          ctx.lineWidth = 3;
          ctx.shadowColor = "#60a5fa";
          ctx.shadowBlur = 18;
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r + wobble + 6, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }
        // photo for player pieces
        if (e.isPlayer && photoRef.current) {
          ctx.save();
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r - 2, 0, Math.PI * 2);
          ctx.clip();
          const d = (e.r - 2) * 2;
          ctx.drawImage(photoRef.current, e.x - e.r + 2, e.y - e.r + 2, d, d);
          ctx.restore();
        }
        // weapon ring
        if (e.weapon) {
          const wColor = e.weapon === "drain" ? "#22d3ee" : "#f87171";
          const remain = Math.max(0, (e.weaponUntil || 0) - tnow);
          const fade = Math.min(1, remain / 2); // fade out last 2s
          // pulsing ring
          const pulse = e.weapon === "drain"
            ? 6 + Math.sin(tnow * 4) * 4
            : 6 + Math.sin(tnow * 8) * 6;
          ctx.globalAlpha = 0.5 + 0.5 * fade;
          ctx.strokeStyle = wColor;
          ctx.lineWidth = Math.max(3, e.r * 0.1);
          ctx.setLineDash([6, 4]);
          ctx.lineDashOffset = -tnow * 30;
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r + pulse, 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.lineDashOffset = 0;
          // outer aura ring
          ctx.globalAlpha = 0.25 * fade;
          ctx.lineWidth = Math.max(2, e.r * 0.06);
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.r + pulse + 12 + Math.sin(tnow * 3) * 4, 0, Math.PI * 2);
          ctx.stroke();
          ctx.globalAlpha = 1;
        }
        // inner ring
        ctx.strokeStyle = "rgba(255,255,255,0.35)";
        ctx.lineWidth = Math.max(2, e.r * 0.06);
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.r - ctx.lineWidth / 2, 0, Math.PI * 2);
        ctx.stroke();
        // name + mass
        if (e.name) {
          const hasPhoto = e.isPlayer && photoRef.current;
          if (hasPhoto) {
            ctx.shadowColor = "rgba(0,0,0,0.9)";
            ctx.shadowBlur = 6;
          }
          ctx.fillStyle = "white";
          ctx.font = `bold ${Math.max(12, e.r * 0.35)}px ui-sans-serif, system-ui`;
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(e.name, e.x, hasPhoto ? e.y + e.r * 0.55 : e.y - e.r * 0.15);
          ctx.font = `${Math.max(10, e.r * 0.25)}px ui-sans-serif, system-ui`;
          if (!hasPhoto) {
            ctx.fillText(String(Math.floor(massFromR(e.r))), e.x, e.y + e.r * 0.25);
          }
          ctx.shadowBlur = 0;
        }
        ctx.restore();
      }

      // ---- update + render effects ----
      const dtMs = dt * 1000;
      for (let i = s.effects.length - 1; i >= 0; i--) {
        const ef = s.effects[i];
        ef.life -= dtMs;
        if (ef.life <= 0) {
          s.effects.splice(i, 1);
          continue;
        }
        if (ef.kind === "drain-particle" && ef.targetId !== undefined) {
          const target =
            s.pieces.find((p) => p.id === ef.targetId) ||
            s.bots.find((b) => b.id === ef.targetId);
          if (target) {
            const dx = target.x - ef.x, dy = target.y - ef.y;
            const d = Math.hypot(dx, dy) || 1;
            const accel = 0.6;
            ef.vx += (dx / d) * accel;
            ef.vy += (dy / d) * accel;
            ef.vx *= 0.92; ef.vy *= 0.92;
            ef.x += ef.vx; ef.y += ef.vy;
            if (d < target.r * 0.4) {
              s.effects.splice(i, 1);
              continue;
            }
          } else {
            s.effects.splice(i, 1);
            continue;
          }
        } else if (ef.kind === "spark") {
          ef.x += ef.vx;
          ef.y += ef.vy;
          ef.vx *= 0.96; ef.vy *= 0.96;
        } else if (ef.kind === "shockwave") {
          const t = 1 - ef.life / ef.maxLife;
          ef.radius = (ef.maxRadius || 200) * t;
        } else if (ef.kind === "teleport-flash") {
          const t = 1 - ef.life / ef.maxLife;
          ef.radius = (ef.maxRadius || 60) * t;
        }
      }
      // render effects
      for (const ef of s.effects) {
        const alpha = Math.max(0, ef.life / ef.maxLife);
        if (ef.kind === "shockwave" || ef.kind === "teleport-flash") {
          ctx.save();
          ctx.globalAlpha = alpha;
          ctx.strokeStyle = ef.color;
          ctx.lineWidth = (ef.kind === "teleport-flash" ? 3 : 4) / s.cam.zoom;
          ctx.shadowColor = ef.color;
          ctx.shadowBlur = ef.kind === "teleport-flash" ? 28 : 20;
          ctx.beginPath();
          ctx.arc(ef.x, ef.y, ef.radius || 0, 0, Math.PI * 2);
          ctx.stroke();
          if (ef.kind === "teleport-flash") {
            // inner sparkly fill
            ctx.globalAlpha = alpha * 0.4;
            ctx.fillStyle = ef.color;
            ctx.beginPath();
            ctx.arc(ef.x, ef.y, (ef.radius || 0) * 0.4, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
        } else {
          ctx.save();
          ctx.globalAlpha = alpha;
          ctx.fillStyle = ef.color;
          ctx.shadowColor = ef.color;
          ctx.shadowBlur = 12;
          ctx.beginPath();
          ctx.arc(ef.x, ef.y, ef.size * alpha, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      }
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;

      ctx.restore();

      // ---- Minimap ----
      const mm = minimapRef.current;
      if (mm) {
        const mctx = mm.getContext("2d");
        if (mctx) {
          const MW = mm.width, MH = mm.height;
          mctx.clearRect(0, 0, MW, MH);
          mctx.fillStyle = "rgba(10, 12, 24, 0.7)";
          mctx.fillRect(0, 0, MW, MH);
          mctx.strokeStyle = "rgba(167, 139, 250, 0.5)";
          mctx.lineWidth = 1;
          mctx.strokeRect(0.5, 0.5, MW - 1, MH - 1);
          const sx = MW / WORLD, sy = MH / WORLD;
          // bots
          for (const b of s.bots) {
            mctx.fillStyle = b.color || "#ffffff";
            mctx.globalAlpha = 0.85;
            mctx.beginPath();
            mctx.arc(b.x * sx, b.y * sy, Math.max(1.2, b.r * sx * 0.8), 0, Math.PI * 2);
            mctx.fill();
          }
          // weapons
          for (const w of s.weapons) {
            mctx.fillStyle =
              w.kind === "drain" ? "#22d3ee" :
              w.kind === "bomb" ? "#f87171" :
              w.kind === "shield" ? "#60a5fa" :
              w.kind === "slime" ? "#84cc16" :
              "#a78bfa";
            mctx.globalAlpha = 0.9;
            mctx.fillRect(w.x * sx - 1.5, w.y * sy - 1.5, 3, 3);
          }
          // player pieces (highlighted)
          mctx.globalAlpha = 1;
          for (const p of s.pieces) {
            mctx.fillStyle = "#34d399";
            mctx.shadowColor = "#34d399";
            mctx.shadowBlur = 8;
            mctx.beginPath();
            mctx.arc(p.x * sx, p.y * sy, Math.max(2, p.r * sx * 0.9), 0, Math.PI * 2);
            mctx.fill();
          }
          mctx.shadowBlur = 0;
          // viewport rectangle
          const vw = (W / s.cam.zoom) * sx;
          const vh = (H / s.cam.zoom) * sy;
          const vx = s.cam.x * sx - vw / 2;
          const vy = s.cam.y * sy - vh / 2;
          mctx.strokeStyle = "rgba(255, 255, 255, 0.6)";
          mctx.lineWidth = 1;
          mctx.strokeRect(vx, vy, vw, vh);
          mctx.globalAlpha = 1;
        }
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onGameOver]);

  // HUD updates
  useEffect(() => {
    const t = setInterval(() => {
      const s = stateRef.current;
      const playerPieces = s.pieces.filter((p) => p.isPlayer);
      const totalMass = playerPieces.reduce((m, p) => m + massFromR(p.r), 0);
      setScore(Math.floor(totalMass));

      // active weapon (any piece carrying one)
      const armed = playerPieces.find((p) => p.weapon);
      setActiveWeapon(armed && armed.weapon ? { kind: armed.weapon, until: armed.weaponUntil || 0 } : null);

      // group player pieces in leaderboard as one entry
      const entries: { name: string; score: number; isPlayer?: boolean }[] = [];
      if (s.alive && playerPieces.length > 0) {
        entries.push({ name: playerPieces[0].name || "You", score: Math.floor(totalMass), isPlayer: true });
      }
      for (const b of s.bots) {
        entries.push({ name: b.name!, score: Math.floor(massFromR(b.r)) });
      }
      entries.sort((a, b) => b.score - a.score);
      setLeaderboard(entries.slice(0, 10));
    }, 250);
    return () => clearInterval(t);
  }, []);

  const weaponSecondsLeft = activeWeapon
    ? Math.max(0, Math.ceil(activeWeapon.until - performance.now() / 1000))
    : 0;

  return (
    <>
      <canvas
        ref={canvasRef}
        className="fixed inset-0 block"
        style={{ touchAction: "none", WebkitUserSelect: "none", userSelect: "none" }}
      />
      {/* Minimap */}
      <div className="pointer-events-none fixed right-2 bottom-2 z-10 rounded-xl border border-white/10 bg-black/40 p-1.5 backdrop-blur-md sm:right-4 sm:bottom-4 sm:p-2">
        <canvas
          ref={minimapRef}
          width={160}
          height={160}
          className="block rounded-md"
          style={{ width: 140, height: 140 }}
        />
      </div>
      {/* HUD */}
      <div className="pointer-events-none fixed left-4 bottom-4 z-10 rounded-xl border border-white/10 bg-black/40 px-4 py-3 backdrop-blur-md">
        <div className="text-xs uppercase tracking-widest text-white/60">Mass</div>
        <div className="text-3xl font-bold text-white" style={{ textShadow: "0 0 20px rgba(52,211,153,0.6)" }}>
          {score}
        </div>
        {activeWeapon && (
          <div className="mt-2 flex items-center gap-2">
            <span
              className="rounded-md px-2 py-0.5 text-xs font-bold text-black animate-pulse"
              style={{
                background:
                  activeWeapon.kind === "drain" ? "#22d3ee" :
                  activeWeapon.kind === "bomb" ? "#f87171" :
                  activeWeapon.kind === "shield" ? "#60a5fa" :
                  activeWeapon.kind === "slime" ? "#84cc16" :
                  "#a78bfa",
                boxShadow: `0 0 14px ${
                  activeWeapon.kind === "drain" ? "#22d3ee" :
                  activeWeapon.kind === "bomb" ? "#f87171" :
                  activeWeapon.kind === "shield" ? "#60a5fa" :
                  activeWeapon.kind === "slime" ? "#84cc16" :
                  "#a78bfa"
                }`,
              }}
            >
              {activeWeapon.kind === "drain" ? "⚡ Drain" :
               activeWeapon.kind === "bomb" ? "💣 Bomb" :
               activeWeapon.kind === "shield" ? "🛡️ Shield" :
               activeWeapon.kind === "slime" ? "🟢 Slime — click to drop" :
               "✨ Teleport — click to blink"}
            </span>
            <span className="text-xs text-white/70">{weaponSecondsLeft}s</span>
          </div>
        )}
      </div>
      <div className="pointer-events-none fixed right-2 top-2 z-10 w-44 rounded-xl border border-white/10 bg-black/40 px-3 py-2 backdrop-blur-md sm:right-4 sm:top-4 sm:w-60 sm:px-4 sm:py-3">
        <div className="mb-2 text-xs uppercase tracking-widest text-white/60">Leaderboard</div>
        <ol className="space-y-0.5 sm:space-y-1">
          {leaderboard.map((p, i) => (
            <li key={i} className={`flex justify-between text-xs sm:text-sm ${p.isPlayer ? "font-bold text-emerald-400" : "text-white/80"}`}>
              <span className="truncate">{i + 1}. {p.name}</span>
              <span>{p.score}</span>
            </li>
          ))}
        </ol>
      </div>
      {/* Mobile hint */}
      <div className="pointer-events-none fixed left-1/2 top-3 z-10 -translate-x-1/2 rounded-full border border-white/10 bg-black/40 px-3 py-1 text-[11px] text-white/70 backdrop-blur-md sm:hidden">
        Drag to move · double-tap to split
      </div>
      {/* Desktop hint */}
      <div className="pointer-events-none fixed left-1/2 top-3 z-10 hidden -translate-x-1/2 rounded-full border border-white/10 bg-black/40 px-3 py-1 text-xs text-white/70 backdrop-blur-md sm:block">
        Move with mouse · Space/dbl-click = split · Click to use 🟢/✨ · 🛡️ auto-shield
      </div>
    </>
  );
}
